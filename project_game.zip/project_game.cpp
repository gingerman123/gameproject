﻿// project_game.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include <iostream>
#include <vector>
#include "console_view.h"
#include "class.h"



// 수풀 속에서 랜덤 확률로 포켓몬나옴

using namespace std;


void voi_fir_sel_mon(player& who, string what) {
    
    string m_type_input = what;
    
    if (m_type_input == "물") {
        monster* m1 = new mon_water();
        what_mon_type(m1);
        get_what(m1);
        who._set_mon_list(1, "물");
        delete m1;
    }
    else if (m_type_input == "불") {
        monster* m1 = new mon_fire();
        what_mon_type(m1);
        get_what(m1);
        who._set_mon_list(1, "불");
        delete m1;
    }
    else if (m_type_input == "풀") {
        monster* m1 = new mon_leaf();
        what_mon_type(m1);
        get_what(m1);
        who._set_mon_list(1, "풀");
        delete m1;
    }
}




int main()
{
    string what_next;
    string user_name;
    bool game_over = true;
    player P1;

    

    // fight screen

    system("cls");
    con_init();
    con_out(80, 50, "img/fight_screen/틀.txt");





    cin >> what_next;


    
       
    while (game_over) {
        what_next = con_first_view();

        if (what_next == "start") {
            while (true) {
                what_next = con_start_view();

                if (what_next == "story mode") {
                    what_next = con_storymode_view();
                    if (what_next == "return") {
                        what_next = "take a break";
                    }
                }
                if (what_next == "fight mode") {                //fight mode 진입
                    user_name = con_name_set_view();            //이름 설정화면 출력
                    P1._set_username(user_name);                //P1 에 사용자 이름 저장
                    what_next = con_first_monster_view();       //  첫몬스터 선택화면 출력
                    con_sel_mon_view(what_next);                // 처음 선택한 몬스터 con 출력       
                    voi_fir_sel_mon(P1, what_next);             // P1 처음 선택한 몬스터 저장


                                       
                    
                }
                if (what_next == "return") {
                    break;
                }
            }
        }
        else if (what_next == "credit") {
            //what_next = con_start_view();
        }
        else if (what_next == "exit") {
            game_over = false;
        }
   }


    
    

    return 0;
}

// 프로그램 실행: <Ctrl+F5> 또는 [디버그] > [디버깅하지 않고 시작] 메뉴
// 프로그램 디버그: <F5> 키 또는 [디버그] > [디버깅 시작] 메뉴

// 시작을 위한 팁: 
//   1. [솔루션 탐색기] 창을 사용하여 파일을 추가/관리합니다.
//   2. [팀 탐색기] 창을 사용하여 소스 제어에 연결합니다.
//   3. [출력] 창을 사용하여 빌드 출력 및 기타 메시지를 확인합니다.
//   4. [오류 목록] 창을 사용하여 오류를 봅니다.
//   5. [프로젝트] > [새 항목 추가]로 이동하여 새 코드 파일을 만들거나, [프로젝트] > [기존 항목 추가]로 이동하여 기존 코드 파일을 프로젝트에 추가합니다.
//   6. 나중에 이 프로젝트를 다시 열려면 [파일] > [열기] > [프로젝트]로 이동하고 .sln 파일을 선택합니다.
